using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.SharpZipLib.Zip;
using System.IO;
using System.Threading;

namespace ZipTest
{
    public partial class FormZip : Form
    {
        public FormZip()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButtonZip.Checked = true;
        }

        private void buttonOpenFile_Click(object sender, EventArgs e)
        {
            //show a openfiledialog to select a file
            OpenFileDialog f = new OpenFileDialog();
            f.Multiselect = false;
            if (f.ShowDialog() == DialogResult.OK)
            {
                textBoxFileName.Text = f.FileName;
            }
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (textBoxFileName.Text != "")
            {
                if (radioButtonZip.Checked == true)
                {
                    //start a new thread to zip it
                    Thread th = new Thread(new ThreadStart(Zip));
                    th.Start();
                }
                else
                {
                    //start a new thread to unzip it
                    Thread th = new Thread(new ThreadStart(UnZip));
                    th.Start();
                }
            }
        }

        private void Zip()
        {
            toolStripStatusLabel1.Text = "Zipping...";
            SetButtonOK(false);
            ZipHelp.Zip(textBoxFileName.Text, textBoxFileName.Text + ".zip", 4096);
            toolStripStatusLabel1.Text = "Done";
            SetButtonOK(true);
        }

        private void UnZip()
        {
            toolStripStatusLabel1.Text = "UnZipping...";
            SetButtonOK(false);
            ZipHelp.UnZip(textBoxFileName.Text, Path.GetDirectoryName(textBoxFileName.Text), 4096);
            toolStripStatusLabel1.Text = "Done";
            SetButtonOK(true);
        }

        //the method to set button's state
        private void SetButtonOK(bool Enable)
        {
            if (buttonOK.InvokeRequired)
                buttonOK.Invoke(new SetEnableCallBack(SetButtonOK), new object[] { Enable });
            else
                buttonOK.Enabled = Enable;
        }

        //delegate to call back
        delegate void SetEnableCallBack(bool Enable);
    }
}